/* ==============================================================================================  */
/*                                   wheelnav.datetime.js - v0.1.0                                 */
/* ==============================================================================================  */
/* This is a small javascript library for wheel based date and time.                               */
/* Requires wheelnav.js library (http://wheelnavjs.softwaretailoring.net)                          */
/* ==============================================================================================  */
/* Check http://wheelnavjs.softwaretailoring.net/datetime for samples.                             */
/* Fork https://github.com/softwaretailoring/wheelnav.datetime for contribution.                   */
/* =============================================================================================== */
/* Copyright © 2015 Gábor Berkesi (http://softwaretailoring.net)                                   */
/* Licensed under MIT (https://github.com/softwaretailoring/wheelnav.datetime/blob/master/LICENSE) */
/* =============================================================================================== */



wheelnavdatetime = function (divId) {

    this.divId = divId;

    this.wheelTypes = {
        Null: "Null",
        Menu: "Menu",
        Donut: "Donut"
    };

    this.wheelnavYear = null;
    this.wheelnavMonth = null;
    this.wheelnavDay = null;
    this.wheelnavHour = null;
    this.wheelnavMin = null;
    this.wheelnavSec = null;
    this.selectionEnable = false;
    this.timeVisible = false;
    this.fixDate = true;
    this.fixTime = true;
    this.slicePathType = this.wheelTypes.Donut;
    this.percentYearMin = 0;
    this.percentYearMax = 0;
    this.percentMonthMin = 0.05;
    this.percentMonthMax = 0.35;
    this.percentDayMin = 0.39;
    this.percentDayMax = 0.68;
    this.percentHourMin = 0.72;
    this.percentHourMax = 1;
    this.titleRotateAngle = true;
    this.tooltip = false;
    this.attachedTextString = null;

};


wheelnavdatetime.prototype.initWheelNav = function (wheelnav, minPercent, maxPercent, sliceType, fixed) {

    wheelnav.slicePathCustom = new slicePathCustomization();
    wheelnav.sliceSelectedPathCustom = new slicePathCustomization();
    wheelnav.sliceHoverPathCustom = new slicePathCustomization();

    if (sliceType == this.wheelTypes.Donut) {
        wheelnav.slicePathFunction = slicePath().DonutSlice;
        wheelnav.slicePathCustom.minRadiusPercent = minPercent;
        wheelnav.slicePathCustom.maxRadiusPercent = maxPercent;

        wheelnav.sliceSelectedPathCustom.minRadiusPercent = minPercent;
        wheelnav.sliceSelectedPathCustom.maxRadiusPercent = maxPercent;
    }

    if (sliceType == this.wheelTypes.Null) {
        wheelnav.slicePathFunction = slicePath().DonutSlice;
        wheelnav.slicePathCustom.titleRadiusPercent = minPercent;

        wheelnav.sliceSelectedPathCustom.titleRadiusPercent = wheelnav.slicePathCustom.titleRadiusPercent;
    }


  wheelnav.colors = new Array("#EEE");

    wheelnav.slicePathAttr = { fill: "#EEE", stroke: "#c5c5c5", "stroke-width": 1, cursor: 'pointer', opacity: 1 };
    wheelnav.sliceSelectedAttr = { fill: "#0020b7", stroke: "#2b9464", "stroke-width": 1, cursor: 'default', opacity: 1 };
    wheelnav.sliceHoverAttr = { stroke: "#c5c5c5", "stroke-width": 1 };

    wheelnav.titleAttr = { font: '100 8px Impact, Charcoal, sans-serif', fill: "#111", stroke: "none", cursor: 'pointer', opacity: 1 };
    wheelnav.titleSelectedAttr = { font: '100 8px Impact, Charcoal, sans-serif', fill: "#FFF", cursor: 'default', opacity: 1 };


    wheelnav.animateeffect = "linear";
    wheelnav.navItemsEnabled = this.selectionEnable;



    if (!fixed) {
        wheelnav.navAngle = 0;


    }
    else {
    }

    if (this.selectionEnable) {
        wheelnav.animatetime = 500;


    }
    else {
        wheelnav.animatetime = 0;


    }
};

wheelnavdatetime.prototype.createWheelNav = function () {
    this.wheelnavYear = new wheelnav(this.divId);
    this.initWheelNav(this.wheelnavYear, this.percentYearMin, this.percentYearMax, this.slicePathType, this.fixed, this.titleRotateAngle, );

    this.wheelnavMonth = new wheelnav(this.divId + "Month", this.wheelnavYear.raphael);
    this.initWheelNav(this.wheelnavMonth, this.percentMonthMin, this.percentMonthMax, this.slicePathType, this.fixed, this.titleRotateAngle, );

    this.wheelnavDay = new wheelnav(this.divId + "Day", this.wheelnavYear.raphael);
    this.initWheelNav(this.wheelnavDay, this.percentDayMin, this.percentDayMax, this.slicePathType, this.fixed, this.titleRotateAngle, );

    this.wheelnavHour = new wheelnav(this.divId + "Hour", this.wheelnavYear.raphael);
    this.initWheelNav(this.wheelnavHour, this.percentHourMin, this.percentHourMax, this.slicePathType, this.fixed, this.titleRotateAngle, );

    
    this.wheelnavMonth.initWheel(["MESSENGER", "VIRAL", "RIBOZYME", "TRANSFER", "RIBOZYME", "ANTISENSE", "VAULT", "EXTRACELLULAR", "PIWI INTERACTING", "NUCLEOLAR",]);
      this.wheelnavMonth.navItems[0].sliceAngle = 200;
      this.wheelnavMonth.navItems[0].attachedTextString = "(types 1)";
      
      this.wheelnavMonth.navItems[1].sliceAngle = 32.4;
      this.wheelnavMonth.navItems[1].attachedTextString = "(types 2)";
      
      this.wheelnavMonth.navItems[2].sliceAngle = 32.4;
      this.wheelnavMonth.navItems[2].attachedTextString = "(types 3)";

      this.wheelnavMonth.navItems[3].sliceAngle = 25.2;
      this.wheelnavMonth.navItems[3].attachedTextString = "(types 4)";

      this.wheelnavMonth.navItems[4].sliceAngle = 21.6;
      this.wheelnavMonth.navItems[4].attachedTextString = "(types 5)";

      this.wheelnavMonth.navItems[5].sliceAngle = 14.4;
      this.wheelnavMonth.navItems[5].attachedTextString = "(types 6)";

      this.wheelnavMonth.navItems[6].sliceAngle = 7.2;
      this.wheelnavMonth.navItems[6].attachedTextString = "(types 7)";

      this.wheelnavMonth.navItems[7].sliceAngle = 7.2;
      this.wheelnavMonth.navItems[7].attachedTextString = "(types 8)";

      this.wheelnavMonth.navItems[8].sliceAngle = 3.6;      
      this.wheelnavMonth.navItems[8].attachedTextString = "(types 9)";


      this.wheelnavMonth.titleRotateAngle = 0;
      this.wheelnavMonth.navItemsContinuous = true;
      this.wheelnavMonth.createWheel();

 
    this.wheelnavDay.initWheel(["BRAIN &\n NEUROLOGICAL", "METABOLIC", "INFECTIOUS", "CANCER", "HEART\nLUNG\n& BLOOD", "AGING", "ADDICTION", "MUSCULO-\nSKELETAL\n& SKIN", "DEVELOPMENTAL", "AUTO-\nINFLAMMATORY", "PREGNANCY\n& CHILDBIRTH\nRELATED", "ENVIRONMENTAL", "DEFICIENCY"]);
      this.wheelnavDay.navItems[0].sliceAngle = 27.69;
      this.wheelnavDay.navItems[0].attachedTextString = "(conditions 1)";
      
      this.wheelnavDay.navItems[1].sliceAngle = 27.69;
      this.wheelnavDay.navItems[1].attachedTextString = "(conditions 2)";
      
      this.wheelnavDay.navItems[2].sliceAngle = 27.69;
      this.wheelnavDay.navItems[2].attachedTextString = "(conditions 3)";

      this.wheelnavDay.navItems[3].sliceAngle = 27.69;
      this.wheelnavDay.navItems[3].attachedTextString = "(conditions 4)";

      this.wheelnavDay.navItems[4].sliceAngle = 27.69;
      this.wheelnavDay.navItems[4].attachedTextString = "(conditions 5)";

      this.wheelnavDay.navItems[5].sliceAngle = 27.69;
      this.wheelnavDay.navItems[5].attachedTextString = "(conditions 6)";

      this.wheelnavDay.navItems[6].sliceAngle = 27.69;
      this.wheelnavDay.navItems[6].attachedTextString = "(conditions 7)";

      this.wheelnavDay.navItems[7].sliceAngle = 27.69;
      this.wheelnavDay.navItems[7].attachedTextString = "(conditions 8)";

      this.wheelnavDay.navItems[8].sliceAngle = 27.69;
      this.wheelnavDay.navItems[8].attachedTextString = "(conditions 9)";

      this.wheelnavDay.navItems[9].sliceAngle = 27.69;
      this.wheelnavDay.navItems[9].attachedTextString = "(conditions 10)";

      this.wheelnavDay.navItems[10].sliceAngle = 27.69;
      this.wheelnavDay.navItems[10].attachedTextString = "(conditions 11)";

      this.wheelnavDay.navItems[11].sliceAngle = 27.69; 
      this.wheelnavDay.navItems[11].attachedTextString = "(conditions 12)";

      this.wheelnavDay.navItems[12].sliceAngle = 27.69; 
      this.wheelnavDay.navItems[12].attachedTextString = "(conditions 13)";

      
      this.wheelnavDay.navItems[1].tooltip = "Yay!";
      this.wheelnavDay.titleRotateAngle = 0;
      this.wheelnavDay.navItemsContinuous = true;
      this.wheelnavDay.createWheel();
     
     

    this.wheelnavHour.initWheel(["RNA\nSPLICING", "MODIFICATION", "CRISPR", "TRANSCRIPTION", "TRAFFICKING", "DEGREDATION", "STRUCTURE", "INTERACTIONS", "APTAMERS", "RIBOSWITCHES", "IMAGING",]);
      this.wheelnavHour.navItems[0].sliceAngle = 32.72;
      this.wheelnavHour.navItems[0].attachedTextString = "(types 1)";
      
      this.wheelnavHour.navItems[1].sliceAngle = 32.72;
      this.wheelnavHour.navItems[1].attachedTextString = "(types 2)";
      
      this.wheelnavHour.navItems[2].sliceAngle = 32.72;
      this.wheelnavHour.navItems[2].attachedTextString = "(types 3)";

      this.wheelnavHour.navItems[3].sliceAngle = 32.72;
      this.wheelnavHour.navItems[3].attachedTextString = "(types 4)";

      this.wheelnavHour.navItems[4].sliceAngle = 32.72;
      this.wheelnavHour.navItems[4].attachedTextString = "(types 5)";

      this.wheelnavHour.navItems[5].sliceAngle = 32.72;
      this.wheelnavHour.navItems[5].attachedTextString = "(types 6)";

      this.wheelnavHour.navItems[6].sliceAngle = 32.72; 
      this.wheelnavHour.navItems[6].attachedTextString = "(types 7)";

      this.wheelnavHour.navItems[7].sliceAngle = 32.72; 
      this.wheelnavHour.navItems[7].attachedTextString = "(types 8)";
 
      this.wheelnavHour.navItems[8].sliceAngle = 32.72; 
      this.wheelnavHour.navItems[8].attachedTextString = "(types 9)";

      this.wheelnavHour.navItems[9].sliceAngle = 32.72; 
      this.wheelnavHour.navItems[9].attachedTextString = "(types 10)";      
      
      this.wheelnavHour.titleRotateAngle = 0;
      this.wheelnavHour.navItemsContinuous = true;
      this.wheelnavHour.createWheel();


};

//navItemClicked(0);

searchString = [];
searchString["divWheelnavDateTimeMonth"] = "Types";
searchString["divWheelnavDateTimeDay"] = "Conditions";
searchString["divWheelnavDateTimeHour"] = "Topics";





function navItemClicked(navItemClicked){
    console.log(navItemClicked);
    
    if(navItemClicked == null){
        inputString = searchString["divWheelnavDateTimeMonth"]  + " " + searchString["divWheelnavDateTimeDay"] +" "+ searchString["divWheelnavDateTimeHour"]
        var inputText = document.getElementById("search-bar-input");
        inputText.value = inputString;
        console.log(inputString);
        
    }else{
        inputString = searchString["divWheelnavDateTimeMonth"]  + " " + searchString["divWheelnavDateTimeDay"] +" "+ searchString["divWheelnavDateTimeHour"];
        var inputText = document.getElementById("search-bar-input");
        inputText.value = inputString;
        console.log(inputString);
        searchString[navItemClicked.wheelnav.holderId] = navItemClicked.attachedTextString;
    }
}

